from django.apps import AppConfig


class WechatConfig(AppConfig):
    name = 'wechat'
