# Mynager
Meeting management system with wechat platform

    2014010776 许为民
    2014013440 宋知朋
    2014013445 于远航
    2014013457 郑成伟

