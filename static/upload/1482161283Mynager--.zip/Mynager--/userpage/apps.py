from django.apps import AppConfig


class UserpageConfig(AppConfig):
    name = 'userpage'
