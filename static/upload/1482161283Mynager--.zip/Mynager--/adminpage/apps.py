from django.apps import AppConfig


class AdminpageConfig(AppConfig):
    name = 'adminpage'
